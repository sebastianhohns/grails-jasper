class JasperController {
    JasperService jasperService

    def index = {
        def jasperFile
        if (grailsApplication.config.jasper.dir.reports) {
            jasperFile = grailsApplication.config.jasper.dir.reports
            if (!jasperFile.startsWith("/")) jasperFile = servletContext.getRealPath(jasperFile)
        }
        else {
            jasperFile = servletContext.getRealPath("${pluginContextPath}/reports/")
        }
        if (!jasperFile.endsWith("/")) jasperFile += "/"

        if (params.SUBREPORT_DIR == null) {
            params.SUBREPORT_DIR = jasperFile
        }

        if (params.REPORT_LOCALE == null) {
            params.REPORT_LOCALE = request.getLocale()
        }

        def from = null
        if (params._from) {
            if (jasperService.existFrom(params._from)) {
                GroovyShell shell = new GroovyShell(grailsApplication.classLoader)
                from = shell.evaluate(params._from)
            }
        }

        def inline = Boolean.valueOf(params._inline)

        switch (params._format) {
            case "PDF":
                createBinaryFile(jasperFile, jasperService.PDF_FORMAT, from, params, "pdf", "application/pdf", inline)
                break
            case "HTML":
                render(text: jasperService.generateReport(jasperFile, jasperService.HTML_FORMAT, from, params), contentType: "text/html")
                break
            case "XML":
                render(text: jasperService.generateReport(jasperFile, jasperService.XML_FORMAT, from, params), contentType: "text/xml")
                break
            case "CSV":
                response.setHeader("Content-disposition", "attachment; filename=\"" + params._name + ".csv\"");
                render(text: jasperService.generateReport(jasperFile, jasperService.CSV_FORMAT, from, params), contentType: "text/csv")
                break
            case "XLS":
                createBinaryFile(jasperFile, jasperService.XLS_FORMAT, from, params, "xls", "application/vnd.ms-excel", false)
                break
            case "RTF":
                createBinaryFile(jasperFile, jasperService.RTF_FORMAT, from, params, "rtf", "text/rtf", false)
                break
            case "TEXT":
                render(text: jasperService.generateReport(jasperFile, jasperService.TEXT_FORMAT, from, params), contentType: "text")
                break
            default:
                throw new Exception(message(code: "jasper.controller.invalidFormat", args: [params._format]))
                break
        }
    }

    def createBinaryFile = {jasperFile, format, from, params, ext, mime, inline ->
        def data = jasperService.generateReport(jasperFile, format, from, params).toByteArray()
        if (!inline) {
            response.setHeader("Content-disposition", "attachment; filename=\"" + params._name + "." + ext + "\"");
        }
        response.contentType = mime
        response.outputStream << data
    }

    def admin = {
        render(view: "admin")
    }

}
