class JasperController {
    JasperService jasperService

    def index = {
    		
        def jasperFile
        if (grailsApplication.config.jasper.dir.reports) {
            jasperFile = grailsApplication.config.jasper.dir.reports
            if (!jasperFile.startsWith("/")) jasperFile = servletContext.getRealPath(jasperFile)
        }
        else {
            jasperFile = servletContext.getRealPath("${pluginContextPath}/reports/")
        }
        if (!jasperFile.endsWith("/")) jasperFile += "/"

        if (params.SUBREPORT_DIR == null) {
            params.SUBREPORT_DIR = jasperFile
        }

        if (params.REPORT_LOCALE == null) {
            params.REPORT_LOCALE = request.getLocale()
        }

        def reportData = null
        if (chainModel?.data) {
            reportData = chainModel.data
        }

        def inline = Boolean.valueOf(params._inline)

        switch (params._format) {
            case "PDF":
                createBinaryFile(jasperFile, jasperService.PDF_FORMAT, reportData, params, "pdf", "application/pdf", inline)
                break
            case "HTML":
                render(text: jasperService.generateReport(jasperFile, jasperService.HTML_FORMAT, reportData, params), contentType: "text/html")
                break
            case "XML":
                render(text: jasperService.generateReport(jasperFile, jasperService.XML_FORMAT, reportData, params), contentType: "text/xml")
                break
            case "CSV":
                response.setHeader("Content-disposition", "attachment; filename=\"" + params._name + ".csv\"");
                render(text: jasperService.generateReport(jasperFile, jasperService.CSV_FORMAT, reportData, params), contentType: "text/csv")
                break
            case "XLS":
                createBinaryFile(jasperFile, jasperService.XLS_FORMAT, reportData, params, "xls", "application/vnd.ms-excel", false)
                break
            case "RTF":
                createBinaryFile(jasperFile, jasperService.RTF_FORMAT, reportData, params, "rtf", "text/rtf", false)
                break
            case "TEXT":
                render(text: jasperService.generateReport(jasperFile, jasperService.TEXT_FORMAT, reportData, params), contentType: "text")
                break
            default:
                throw new Exception(message(code: "jasper.controller.invalidFormat", args: [params._format]))
                break
        }
    }

    def createBinaryFile = {jasperFile, format, reportData, params, ext, mime, inline ->
        def data = jasperService.generateReport(jasperFile, format, reportData, params).toByteArray()
        if (!inline) {
            response.setHeader("Content-disposition", "attachment; filename=\"" + params._name + "." + ext + "\"");
        }
        response.contentType = mime
        response.outputStream << data
    }

    def admin = {
        render(view: "admin")
    }

}
