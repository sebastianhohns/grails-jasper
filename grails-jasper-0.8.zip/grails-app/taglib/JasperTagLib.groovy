class JasperTagLib {

    JasperService jasperService

    def jasperReport = {attrs, body ->
        validateAttributes(attrs)
        def appPath = grailsAttributes.getApplicationUri(request)
        def webAppPath = appPath + pluginContextPath
        def delimiter = attrs['delimiter'] ? attrs['delimiter'] : "|"
        		
        def controller = attrs['controller'] ? attrs['controller'] : "jasper"
        def action = attrs['action'] ? attrs['action'] : ""; 

        out << """
      <script type="text/javascript">
        function create(link) {
          link.parentNode._format.value = link.title;
          link.parentNode.submit();
          return false;
        }
      </script>
      <form name="${attrs['jasper']}" action="${appPath}/${controller}/${action}">
      ${delimiter} 
      """
        out << """<input type="hidden" name="_format" />
      <input type="hidden" name="_name" value="${attrs['name']}" />
      <input type="hidden" name="_file" value="${attrs['jasper']}" />
      """

        if (attrs['inline']) {
            out << """<input type="hidden" name="_inline" value="${attrs['inline']}" />
        """
        }

        attrs['format'].split(",").each {
            out << """
        <a href="#" title="${it.trim()}" onClick="return create(this)">
        <img border="0" src="${webAppPath}/images/icons/${it.trim()}.gif" /></a>
        ${delimiter}
      """
        }
        out << "<b>${attrs['name']}</b>"
        out << body()
        out << "</form>"
    }

    private void validateAttributes(attrs) {
        //Verify the 'format' attribute
        def availableFormats = ["PDF", "HTML", "XML", "CSV", "XLS", "RTF", "TEXT"]
        attrs.format.toUpperCase().split(",").each {
            if (!availableFormats.contains(it.trim())) {
                throw new Exception(message(code: "jasper.taglib.invalidFormatAttribute", args: ["${it}", "${availableFormats}"]))
            }
        }
    }

}